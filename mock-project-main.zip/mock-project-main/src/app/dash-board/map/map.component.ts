import { ChartService } from './../../service/chart.service';
import { Component, OnInit } from '@angular/core';
import Highcharts from 'highcharts/highmaps';
import worldMap from '@highcharts/map-collection/custom/world.geo.json';
import { Options } from 'highcharts';
import { DashboardService } from 'src/app/service/dashboard.service';
import L from 'leaflet';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css'],
})
export class MapComponent implements OnInit {
  map!: L.Map;
  centroid: L.LatLngExpression = [32.1, 6.86]; //
  private initMap(): void {
    this.map = L.map('map', {
      center: this.centroid,
      zoom: 2.5,
    });

    const tiles = L.tileLayer(
      'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      {
        maxZoom: 10,

        attribution:
          '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      }
    );
    tiles.addTo(this.map);
  }
  static ScaledRadius(val: number, maxVal: number):number {
    return 100 * (val / maxVal);
  }
  makelocalmap(map: L.Map):void{
    this.doash.GetAllDataCountries().subscribe(
      (response: any) => {
        const maxCofmi = Math.max(...response.map((x:any) => x.confirmed),0);
        for (const cof of response) {
          const lat = cof.location.lng;
          const lon = cof.location.lat;
          const circle  = L.circleMarker([lon, lat],{
            radius: MapComponent.ScaledRadius(cof.confirmed, maxCofmi)
          });circle.addTo(map);
        }
      });
  }
  constructor(private doash: DashboardService) {}

  ngOnInit(): void {
    this.initMap();
    this.makelocalmap(this.map);
  }
}
